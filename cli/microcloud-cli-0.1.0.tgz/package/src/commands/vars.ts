import { MANIFEST_FILE, MicrocloudError, SECRET_REF_RE, VARIABLE_NAME_RE } from '@microcloud/shared';
import type { Command } from 'commander';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { MakeCtx } from '../cli.js';
import type { Ctx } from '../context.js';
import { editToml, ensureTable, type TomlDoc } from '../toml-edit.js';

/** `[variables]` for main, `[env.<name>.variables]` otherwise — same for `secrets`. */
function tablePath(ctx: Ctx, table: 'variables' | 'secrets'): string[] {
  return ctx.envName === 'main' ? [table] : ['env', ctx.envName, table];
}

function parsePair(text: string): [string, string] {
  const eq = text.indexOf('=');
  if (eq <= 0) throw new MicrocloudError('usage', `expected KEY=VALUE, got "${text}"`);
  return [text.slice(0, eq), text.slice(eq + 1)];
}

function assertName(name: string): void {
  if (!VARIABLE_NAME_RE.test(name)) throw new MicrocloudError('invalid_variable', `"${name}" is not a valid variable name (${VARIABLE_NAME_RE})`);
}

/** dotenv subset: KEY=VALUE, optional `export `, quotes, `#` comments and blank lines. */
export function parseDotenv(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (line === '' || line.startsWith('#')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(line);
    if (!m) continue;
    let value = m[2]!.trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1).replace(/\\n/g, '\n');
    } else {
      value = value.replace(/\s+#.*$/, '');
    }
    out[m[1]!] = value;
  }
  return out;
}

async function rewrite(ctx: Ctx, mutate: (doc: TomlDoc) => void): Promise<boolean> {
  const path = join(ctx.cwd, MANIFEST_FILE);
  let source: string;
  try {
    source = await readFile(path, 'utf8');
  } catch {
    throw new MicrocloudError('missing_manifest', 'boxlite.toml not found', 'run `boxlite-app init`');
  }
  const edit = editToml(source, mutate);
  await writeFile(path, edit.text);
  if (edit.droppedComments) ctx.out.note('note: boxlite.toml was rewritten; its comments were dropped');
  return edit.droppedComments;
}

async function varsSet(ctx: Ctx, pairs: string[]): Promise<void> {
  const values = Object.fromEntries(pairs.map(parsePair));
  for (const k of Object.keys(values)) assertName(k);
  const dropped = await rewrite(ctx, (doc) => Object.assign(ensureTable(doc, tablePath(ctx, 'variables')), values));
  for (const [k, v] of Object.entries(values)) ctx.out.line(`set ${k}=${v}${ctx.envName === 'main' ? '' : ` (env ${ctx.envName})`}`);
  ctx.out.data({ file: MANIFEST_FILE, env: ctx.envName, set: values, comments_dropped: dropped });
}

async function varsUnset(ctx: Ctx, names: string[]): Promise<void> {
  const removed: string[] = [];
  const dropped = await rewrite(ctx, (doc) => {
    const table = ensureTable(doc, tablePath(ctx, 'variables'));
    for (const n of names) if (n in table) (delete table[n], removed.push(n));
  });
  for (const n of names) ctx.out.line(removed.includes(n) ? `unset ${n}` : `${n} was not set`);
  ctx.out.data({ file: MANIFEST_FILE, env: ctx.envName, unset: removed, comments_dropped: dropped });
}

async function varsImport(ctx: Ctx, file: string, opts: { dryRun?: boolean }): Promise<void> {
  const values = parseDotenv(await readFile(join(ctx.cwd, file), 'utf8'));
  for (const k of Object.keys(values)) assertName(k);
  const n = Object.keys(values).length;
  if (opts.dryRun) {
    for (const [k, v] of Object.entries(values)) ctx.out.line(`would set ${k}=${v}`);
    ctx.out.data({ file: MANIFEST_FILE, env: ctx.envName, would_set: values });
    return;
  }
  const dropped = await rewrite(ctx, (doc) => Object.assign(ensureTable(doc, tablePath(ctx, 'variables')), values));
  ctx.out.line(`imported ${n} variable${n === 1 ? '' : 's'} from ${file}`);
  ctx.out.data({ file: MANIFEST_FILE, env: ctx.envName, set: values, comments_dropped: dropped });
}

async function secretsRef(ctx: Ctx, name: string, ref: string): Promise<void> {
  assertName(name);
  if (!SECRET_REF_RE.test(ref)) throw new MicrocloudError('invalid_secret_ref', `"${ref}" must look like org/path`);
  const dropped = await rewrite(ctx, (doc) => {
    ensureTable(doc, tablePath(ctx, 'secrets'))[name] = ref;
  });
  ctx.out.line(`secret ${name} → ${ref}`);
  ctx.out.data({ file: MANIFEST_FILE, env: ctx.envName, secrets: { [name]: ref }, comments_dropped: dropped });
}

export function registerVars(app: Command, make: MakeCtx): void {
  const vars = app.command('vars').description('edit [variables] in boxlite.toml (local only; deploy or apply to publish)');
  vars
    .command('set <pairs...>')
    .description('set KEY=VALUE pairs')
    .action(async (pairs: string[], _o: unknown, cmd: Command) => varsSet(await make(cmd), pairs));
  vars
    .command('unset <names...>')
    .description('remove variables')
    .action(async (names: string[], _o: unknown, cmd: Command) => varsUnset(await make(cmd), names));
  vars
    .command('import <file>')
    .description('import KEY=VALUE lines from a dotenv-style file')
    .option('--dry-run', 'print what would change without writing')
    .action(async (file: string, opts: { dryRun?: boolean }, cmd: Command) => varsImport(await make(cmd), file, opts));

  const secrets = app.command('secrets').description('edit [secrets] references in boxlite.toml (local only)');
  secrets
    .command('ref <name> <ref>')
    .description('map NAME to an org secret, e.g. OPENAI_API_KEY org/openai')
    .action(async (name: string, ref: string, _o: unknown, cmd: Command) => secretsRef(await make(cmd), name, ref));
}
