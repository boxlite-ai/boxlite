import { MANIFEST_FILE, MicrocloudError } from '@microcloud/shared';
import type { Command } from 'commander';
import { appendFile, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { MakeCtx } from '../cli.js';
import { LINK_FILE, writeLink, type Ctx } from '../context.js';

const GITIGNORE_LINES = ['.boxlite/', '.env.local'];

export function manifestSkeleton(app: string): string {
  return `# boxlite.toml — manifest for the BoxLite Micro-cloud App "${app}".
# Edit, then run \`boxlite-app check\`; \`boxlite-app app context\` explains every field.
name = "${app}"

[runtime]
image = "node"            # base | python | node
size = "small"            # nano | small | medium | large
build = []                # commands run on the Box after upload, e.g. ["npm ci", "npm run build"]

[[service]]
name = "web"
command = "npm start"     # must listen on $PORT (the platform sets it)
port = 3000               # marks this service as the exposed one; the value is only a hint
health = "/"              # must answer 2xx within 60 s after start

# End-user sign-in. Uncomment to require Google/GitHub login for the listed paths;
# the platform then sends X-BoxLite-User-* headers to your service.
# [auth]
# providers = ["google", "github"]
# protect = ["/app/*"]

# Postgres (Neon). Uncomment to provision a database; files in migrations/ named
# NNNN_name.sql run in order on every deploy. DATABASE_URL is injected.
# [database]
# migrations = "migrations/"

# Plain configuration (visible in the console). Secrets reference org secrets instead:
# [variables]
# LOG_LEVEL = "info"
# [secrets]
# OPENAI_API_KEY = "org/openai"
`;
}

async function exists(path: string): Promise<boolean> {
  try {
    await readFile(path);
    return true;
  } catch {
    return false;
  }
}

async function init(ctx: Ctx, opts: { app?: string }): Promise<void> {
  const api = ctx.api();
  const requested = opts.app ?? ctx.app;
  let info;
  try {
    info = await api.getApp(requested ?? 'me');
  } catch (e) {
    // Not every control plane resolves the App from the key via the `me` alias.
    if (!requested && e instanceof MicrocloudError && e.code === 'not_found_app') throw new MicrocloudError('not_found_app', e.message, 'pass --app <name> (the App this key was created for) or set BOXLITE_APP');
    throw e;
  }
  const app = typeof info.name === 'string' && info.name ? info.name : requested;
  if (!app) throw new MicrocloudError('not_found_app', 'the control plane did not return an App name', 'pass --app <name>');
  const envInfo = info.envs?.find((e) => e.name === ctx.envName);
  const baseVersion = envInfo?.spec_version ?? envInfo?.latest_deployment?.spec_version ?? 0;

  const created: string[] = [];
  const unchanged: string[] = [];

  const tomlPath = join(ctx.cwd, MANIFEST_FILE);
  if (await exists(tomlPath)) unchanged.push(MANIFEST_FILE);
  else {
    await writeFile(tomlPath, manifestSkeleton(app));
    created.push(MANIFEST_FILE);
  }

  if (ctx.link) unchanged.push(LINK_FILE);
  else {
    await writeLink(ctx.cwd, { app, env: ctx.envName, base_version: baseVersion, api_url: api.baseUrl });
    created.push(LINK_FILE);
  }

  const gitignorePath = join(ctx.cwd, '.gitignore');
  if (await exists(gitignorePath)) {
    const current = (await readFile(gitignorePath, 'utf8')).split(/\r?\n/).map((l) => l.trim());
    const missing = GITIGNORE_LINES.filter((l) => !current.includes(l));
    if (missing.length > 0) {
      const text = await readFile(gitignorePath, 'utf8');
      await appendFile(gitignorePath, `${text.endsWith('\n') || text === '' ? '' : '\n'}${missing.join('\n')}\n`);
      created.push(`.gitignore (+${missing.join(', ')})`);
    } else unchanged.push('.gitignore');
  }

  ctx.out.data({ app, env: ctx.envName, base_version: baseVersion, api_url: api.baseUrl, created, unchanged });
  ctx.out.line(`App ${app} · environment ${ctx.envName} · ${api.baseUrl}`);
  for (const f of created) ctx.out.line(`  created    ${f}`);
  for (const f of unchanged) ctx.out.line(`  unchanged  ${f}`);
  if (created.includes(MANIFEST_FILE)) ctx.out.line('next: edit boxlite.toml, then `boxlite-app check` and `boxlite-app deploy`');
}

export function registerInit(program: Command, make: MakeCtx): void {
  program
    .command('init')
    .description('write boxlite.toml, .boxlite/link.json and .gitignore entries in the current directory (never overwrites)')
    .option('--app <name>', 'App name (default: the App the key belongs to)')
    .action(async (opts: { app?: string }, cmd: Command) => init(await make(cmd), opts));
}
