import { checkProject, MicrocloudError, type CheckResult, type Manifest, type MigrationFile, type UploadManifest } from '@microcloud/shared';
import type { PlanRequest } from '../api.js';
import type { Ctx } from '../context.js';
import { checkLines, formatBytes } from '../output.js';

export interface CheckedProject {
  manifest: Manifest;
  upload: UploadManifest;
  migrations: MigrationFile[];
  result: CheckResult;
  source: string;
}

export function invalidManifestError(result: CheckResult, printed = false): MicrocloudError {
  const n = result.errors.length;
  return new MicrocloudError('invalid_manifest', `${n} error${n === 1 ? '' : 's'} in boxlite.toml`, 'fix the errors above and run `boxlite-app check`', {
    errors: result.errors,
    warnings: result.warnings,
    ...(printed ? { printed: true } : {}),
  });
}

/** Runs the local checks; prints warnings, and throws `invalid_manifest` (exit 7) on errors. */
export async function requireCheck(ctx: Ctx): Promise<CheckedProject> {
  const checked = await checkProject(ctx.cwd, ctx.envName);
  if (!checked.result.ok || !checked.manifest || !checked.upload || checked.source === null) {
    if (!ctx.json) for (const line of checkLines(checked.result)) ctx.out.line(line);
    throw invalidManifestError(checked.result, !ctx.json);
  }
  for (const w of checked.result.warnings) ctx.out.note(`warning  ${w.rule}  ${w.message}`);
  return { manifest: checked.manifest, upload: checked.upload, migrations: checked.migrations, result: checked.result, source: checked.source };
}

export function planRequest(ctx: Ctx, checked: CheckedProject, force = false): PlanRequest & { force?: boolean } {
  return {
    manifest: checked.manifest,
    base_version: ctx.baseVersion,
    migrations: checked.migrations,
    upload: { files: checked.upload.files.length, bytes: checked.upload.bytes, warnings: checked.result.warnings.map((w) => w.message) },
    ...(force ? { force } : {}),
  };
}

/** `42 files, 1.3 MB · warning: .env.local looks like a secret file (excluded)` */
export function uploadSummary(checked: CheckedProject): string {
  const secrets = checked.result.warnings.filter((w) => w.rule === 'secret_file').map((w) => w.message);
  let text = `${checked.upload.files.length} files, ${formatBytes(checked.upload.bytes)}`;
  for (const s of secrets) text += ` · warning: ${s}`;
  return text;
}

export function parseInteger(text: string, what: string): number {
  if (!/^\d+$/.test(text)) throw new MicrocloudError('usage', `${what} must be a number (got "${text}")`);
  return Number(text);
}
