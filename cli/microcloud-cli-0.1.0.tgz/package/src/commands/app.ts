import { ACCESS_LEVELS, MANIFEST_FILE, MicrocloudError } from '@microcloud/shared';
import type { Command } from 'commander';
import { mkdir, readdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import * as tar from 'tar';
import type { LogEvent } from '../api.js';
import type { MakeCtx } from '../cli.js';
import { updateLink, writeLink, type Ctx } from '../context.js';
import { abortOnSigint, deployFailedError, followDeployment, TERMINAL_STATUSES } from '../follow.js';
import { formatAgo, formatMs, formatValue, pad, stepLine, table } from '../output.js';
import { eventData } from '../api.js';
import { specToToml } from '../toml-edit.js';
import { parseInteger } from './common.js';
import { registerDb } from './db.js';
import { registerDev } from './dev.js';
import { finishDeployment, followPrinter } from './deploy.js';
import { registerVars } from './vars.js';

async function status(ctx: Ctx): Promise<void> {
  const info = await ctx.api().getApp(ctx.requireApp());
  ctx.out.data(info);
  ctx.out.line(`App ${info.name}`);
  const rows = (info.envs ?? []).map((e) => {
    const d = e.latest_deployment;
    return [e.name, e.status ?? '', e.url ?? '', d ? `#${d.number} ${d.status}` : 'no deployments', e.spec_version !== undefined ? `spec v${e.spec_version}` : ''];
  });
  for (const line of table(rows, '  ')) ctx.out.line(line);
}

async function context(ctx: Ctx, opts: { format?: string }): Promise<void> {
  const format = opts.format === 'json' || ctx.json ? 'json' : 'markdown';
  if (opts.format && opts.format !== 'json' && opts.format !== 'markdown') throw new MicrocloudError('usage', '--format must be markdown or json');
  ctx.requireApp();
  ctx.out.raw(await ctx.api().getContext(format));
}

async function deployments(ctx: Ctx, opts: { limit?: string }): Promise<void> {
  ctx.requireApp();
  const list = await ctx.api().listDeployments(opts.limit !== undefined ? parseInteger(opts.limit, '--limit') : undefined);
  ctx.out.data(list);
  if (list.length === 0) ctx.out.line('no deployments');
  const rows = list.map((d) => [`#${d.number}`, d.kind, d.status, d.spec_version !== undefined ? `v${d.spec_version}` : '', formatAgo(d.created_at), d.message ?? '']);
  for (const line of table(rows)) ctx.out.line(line);
}

function printLog(ctx: Ctx, ev: LogEvent): void {
  ctx.out.line(`${ev.ts ?? ''}  ${pad(ev.source ?? '', 7)} ${ev.line}`.trimStart());
}

async function deployment(ctx: Ctx, nText: string, opts: { follow?: boolean; logs?: boolean; cancel?: boolean }): Promise<void> {
  ctx.requireApp();
  const n = parseInteger(nText, 'deployment number');
  const api = ctx.api();
  if (opts.cancel) {
    const d = await api.cancelDeployment(n);
    ctx.out.data(d);
    ctx.out.line(`#${n}  ${d.status ?? 'cancelled'}`);
    return;
  }
  const d = await api.getDeployment(n);
  if (opts.follow && !TERMINAL_STATUSES.has(d.status)) {
    ctx.out.line(`#${n}  ${d.kind} · ${d.status}${d.message ? ` · ${d.message}` : ''}`);
    const printer = followPrinter(ctx, n, null, { logs: opts.logs });
    const { signal, dispose } = abortOnSigint();
    try {
      await finishDeployment(ctx, await followDeployment(api, n, printer, signal), n, printer);
    } finally {
      dispose();
    }
    return;
  }
  ctx.out.data(d);
  ctx.out.line(`#${n}  ${d.kind} · ${d.status}${d.spec_version !== undefined ? ` · spec v${d.spec_version}` : ''}${d.message ? ` · ${d.message}` : ''}${d.created_at ? ` · ${formatAgo(d.created_at)}` : ''}`);
  for (const s of d.steps ?? []) ctx.out.line(`  ${stepLine(n, s.name, s.detail ?? '', s.ms, s.status === 'failed' ? 'failed' : undefined)}${s.status !== 'failed' && s.status !== 'done' ? `   ${s.status}` : ''}`);
  if (d.url) ctx.out.line(`  url: ${d.url}`);
  if (d.error) ctx.out.line(`  error: ${d.error.step ? `[${d.error.step}] ` : ''}${d.error.message ?? ''}`);
  const tail = d.error?.log_tail ?? d.log_tail ?? [];
  if (opts.logs) for (const line of tail) ctx.out.line(`    ${line}`);
  if (d.status === 'failed') throw deployFailedError(d);
}

async function rollback(ctx: Ctx, nText: string, opts: { withDatabase?: boolean }): Promise<void> {
  ctx.requireApp();
  const to = parseInteger(nText, 'deployment number');
  if (!(await ctx.confirm(`Roll ${ctx.envName} back to deployment #${to}${opts.withDatabase ? ' including the database' : ''}?`, 'roll back'))) {
    ctx.out.line('cancelled');
    return;
  }
  const api = ctx.api();
  const d = await api.createDeployment({ kind: 'rollback', to, ...(opts.withDatabase ? { with_database: true } : {}) });
  ctx.out.line(`Rollback #${d.number} → release of #${to} started`);
  const printer = followPrinter(ctx, d.number, null);
  const { signal, dispose } = abortOnSigint();
  try {
    await finishDeployment(ctx, await followDeployment(api, d.number, printer, signal), d.number, printer);
  } finally {
    dispose();
  }
}

async function logs(ctx: Ctx, opts: { source?: string; follow?: boolean; since?: string; limit?: string }): Promise<void> {
  ctx.requireApp();
  const api = ctx.api();
  const query = { source: opts.source, since: opts.since, limit: opts.limit !== undefined ? parseInteger(opts.limit, '--limit') : undefined };
  if (!opts.follow) {
    const lines = await api.getLogs(query);
    ctx.out.data(lines);
    for (const l of lines) printLog(ctx, l);
    return;
  }
  const { signal, dispose } = abortOnSigint();
  try {
    for await (const ev of api.followLogs(query, signal)) {
      if (ev.event !== 'log') continue;
      const log = eventData<LogEvent>(ev);
      if (!log) continue;
      ctx.out.data(log);
      printLog(ctx, log);
    }
  } catch (e) {
    if ((e as Error).name !== 'AbortError') throw e;
  } finally {
    dispose();
  }
}

async function services(ctx: Ctx): Promise<void> {
  ctx.requireApp();
  const list = await ctx.api().listServices();
  ctx.out.data(list);
  const rows = list.map((s) => [s.name, s.state, s.health ?? '', s.restarts !== undefined ? `restarts ${s.restarts}` : '', s.last_exit_code != null ? `exit ${s.last_exit_code}` : '', s.pid != null ? `pid ${s.pid}` : '']);
  for (const line of table(rows)) ctx.out.line(line);
}

async function restart(ctx: Ctx, service?: string): Promise<void> {
  ctx.requireApp();
  const api = ctx.api();
  const names = service ? [service] : (await api.listServices()).map((s) => s.name);
  for (const name of names) {
    await api.restartService(name);
    ctx.out.line(`restarted ${name}`);
  }
  ctx.out.data({ restarted: names });
}

async function access(ctx: Ctx, action?: string, value?: string): Promise<void> {
  ctx.requireApp();
  const api = ctx.api();
  if (action === undefined) {
    const current = await api.getAccess();
    ctx.out.data(current);
    ctx.out.line(`access ${current.access}`);
    return;
  }
  if (action !== 'set' || !value) throw new MicrocloudError('usage', 'usage: boxlite-app app access [set private|org|public]');
  if (!(ACCESS_LEVELS as readonly string[]).includes(value)) throw new MicrocloudError('usage', `access must be one of ${ACCESS_LEVELS.join(', ')}`);
  if (value === 'public' && !ctx.yes) throw new MicrocloudError('confirmation_required', 'making the app public exposes it to everyone on the internet', 'rerun with --yes if that is intended');
  const updated = await api.setAccess(value);
  ctx.out.data(updated);
  ctx.out.line(`access ${updated.access ?? value}`);
}

async function pull(ctx: Ctx): Promise<void> {
  ctx.requireApp();
  const spec = await ctx.api().getSpec();
  const path = join(ctx.cwd, MANIFEST_FILE);
  let backedUp = false;
  try {
    await readFile(path);
    await rename(path, `${path}.bak`);
    backedUp = true;
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e;
  }
  await writeFile(path, specToToml(spec));
  const version = typeof spec.version === 'number' ? spec.version : undefined;
  if (version !== undefined) await updateLink(ctx.cwd, { base_version: version });
  ctx.out.data({ file: MANIFEST_FILE, version, backup: backedUp ? `${MANIFEST_FILE}.bak` : null });
  ctx.out.line(`wrote boxlite.toml from spec v${version ?? '?'}${backedUp ? ' (previous file kept as boxlite.toml.bak, including any [env.*] overrides and comments)' : ''}`);
}

async function exportSpec(ctx: Ctx): Promise<void> {
  ctx.requireApp();
  ctx.out.raw(JSON.stringify(await ctx.api().getSpec(), null, ctx.json ? 0 : 2));
}

async function clone(ctx: Ctx, appName: string, opts: { deployment?: string }): Promise<void> {
  const api = ctx.api().scoped(appName, ctx.envName);
  let number = opts.deployment !== undefined ? parseInteger(opts.deployment, '--deployment') : undefined;
  let specVersion: number | undefined;
  if (number === undefined) {
    const env = await api.getEnv();
    number = env.latest_deployment?.number ?? undefined;
    specVersion = env.spec_version ?? undefined;
    if (number === undefined) throw new MicrocloudError('not_found', `${appName}/${ctx.envName} has no deployment to clone`, 'pass --deployment <N>');
  }
  const dest = resolve(ctx.cwd, appName);
  await mkdir(dest, { recursive: true });
  if ((await readdir(dest)).length > 0) throw new MicrocloudError('exists', `./${appName}/ already exists and is not empty`, 'remove it or clone from another directory');
  const source = await api.deploymentSource(number);
  await pipeline(Readable.from(source), tar.x({ cwd: dest }));
  if (specVersion === undefined) specVersion = (await api.getDeployment(number)).spec_version;
  await writeLink(dest, { app: appName, env: ctx.envName, base_version: specVersion ?? 0, api_url: api.baseUrl });
  ctx.out.data({ app: appName, env: ctx.envName, deployment: number, dir: dest });
  ctx.out.line(`cloned ${appName}/${ctx.envName} (deployment #${number}) into ./${appName}/`);
}

async function envCreate(ctx: Ctx, name: string, opts: { from?: string; withData?: boolean }): Promise<void> {
  ctx.requireApp();
  const env = await ctx.api().createEnv({ name, from: opts.from ?? 'main', ...(opts.withData ? { with_data: true } : {}) });
  ctx.out.data(env);
  ctx.out.line(`environment ${name} created from ${opts.from ?? 'main'}${opts.withData ? ' with data' : ''}${env.url ? ` · ${env.url}` : ''}`);
}

async function envDelete(ctx: Ctx, name: string): Promise<void> {
  ctx.requireApp();
  if (name === 'main') throw new MicrocloudError('forbidden', 'the main environment cannot be deleted');
  if (!(await ctx.confirm(`Delete environment ${name} and its Box, database branch and volumes?`, 'delete the environment'))) {
    ctx.out.line('cancelled');
    return;
  }
  await ctx.api().deleteEnv(name);
  ctx.out.data({ deleted: name });
  ctx.out.line(`environment ${name} deleted`);
}

async function scheduleRun(ctx: Ctx, name: string): Promise<void> {
  ctx.requireApp();
  const result = await ctx.api().runSchedule(name);
  ctx.out.data(result ?? { ran: name });
  ctx.out.line(`schedule ${name} triggered${result && typeof result === 'object' && 'status' in result ? ` · ${formatValue((result as { status: unknown }).status)}` : ''}`);
}

export function registerApp(program: Command, make: MakeCtx): void {
  const app = program.command('app').description('inspect and operate the linked App');

  app.command('status').description('environments, URLs and latest deployments').action(async (_o: unknown, cmd: Command) => status(await make(cmd)));
  app
    .command('context')
    .description('everything an agent needs to work on this App')
    .option('--format <fmt>', 'markdown | json', 'markdown')
    .action(async (opts: { format?: string }, cmd: Command) => context(await make(cmd), opts));
  app
    .command('deployments')
    .description('recent deployments of the environment')
    .option('--limit <n>', 'how many')
    .action(async (opts: { limit?: string }, cmd: Command) => deployments(await make(cmd), opts));
  app
    .command('deployment <n>')
    .description('details of one deployment')
    .option('--follow', 'follow a running deployment until it finishes')
    .option('--logs', 'include log lines')
    .option('--cancel', 'cancel a queued or running deployment')
    .action(async (n: string, opts: { follow?: boolean; logs?: boolean; cancel?: boolean }, cmd: Command) => deployment(await make(cmd), n, opts));
  app
    .command('rollback <n>')
    .description('switch the environment back to the release of deployment N')
    .option('--with-database', 'also restore the database to its state at that deployment')
    .option('-y, --yes', 'do not ask for confirmation')
    .action(async (n: string, opts: { withDatabase?: boolean }, cmd: Command) => rollback(await make(cmd), n, opts));
  app
    .command('logs')
    .description('service, build and system logs')
    .option('--source <name>', 'web | worker | build | system | <service>')
    .option('--follow', 'stream new lines (Ctrl-C to stop)')
    .option('--since <duration>', 'e.g. 1h, 30m, or an ISO timestamp')
    .option('--limit <n>', 'max lines')
    .action(async (opts: { source?: string; follow?: boolean; since?: string; limit?: string }, cmd: Command) => logs(await make(cmd), opts));
  app.command('services').description('service states, health, restarts').action(async (_o: unknown, cmd: Command) => services(await make(cmd)));
  app
    .command('restart [service]')
    .description('restart one service or all of them')
    .action(async (service: string | undefined, _o: unknown, cmd: Command) => restart(await make(cmd), service));
  app
    .command('access [action] [value]')
    .description('show or set who can reach the app: app access | app access set private|org|public --yes')
    .option('-y, --yes', 'required to set public')
    .action(async (action: string | undefined, value: string | undefined, _o: unknown, cmd: Command) => access(await make(cmd), action, value));
  app.command('pull').description('rewrite boxlite.toml from the environment spec (old file kept as boxlite.toml.bak)').action(async (_o: unknown, cmd: Command) => pull(await make(cmd)));
  app.command('export').description('print the environment spec as JSON').action(async (_o: unknown, cmd: Command) => exportSpec(await make(cmd)));
  app
    .command('clone <app>')
    .description('download the source of a deployment into ./<app>/ and link it')
    .option('--deployment <n>', 'deployment number (default: latest)')
    .action(async (name: string, opts: { deployment?: string }, cmd: Command) => clone(await make(cmd), name, opts));

  const env = app.command('env').description('environments');
  env
    .command('create <name>')
    .description('create an environment from another one')
    .option('--from <env>', 'source environment', 'main')
    .option('--with-data', 'copy the database data too')
    .action(async (name: string, opts: { from?: string; withData?: boolean }, cmd: Command) => envCreate(await make(cmd), name, opts));
  env
    .command('delete <name>')
    .description('delete an environment')
    .option('-y, --yes', 'do not ask for confirmation')
    .action(async (name: string, _o: unknown, cmd: Command) => envDelete(await make(cmd), name));

  app
    .command('schedule')
    .description('scheduled jobs')
    .command('run <name>')
    .description('trigger a schedule now')
    .action(async (name: string, _o: unknown, cmd: Command) => scheduleRun(await make(cmd), name));

  registerDb(app, make);
  registerVars(app, make);
  registerDev(app, make);
}
