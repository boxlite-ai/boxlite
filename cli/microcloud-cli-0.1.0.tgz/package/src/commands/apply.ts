import type { Command } from 'commander';
import type { MakeCtx } from '../cli.js';
import { updateLink, type Ctx } from '../context.js';
import { abortOnSigint, deployFailedError, followDeployment } from '../follow.js';
import { pad } from '../output.js';
import { runPlan } from './plan.js';

async function apply(ctx: Ctx, opts: { force?: boolean }): Promise<void> {
  const { checked, plan } = await runPlan(ctx, opts.force === true);
  const changes = plan.changes ?? [];
  const applicable = changes.filter((c) => c.kind !== 'online_only');
  if (applicable.length === 0) {
    ctx.out.line('nothing to apply');
    return;
  }
  if (!(await ctx.confirm(`Apply ${applicable.length} change${applicable.length === 1 ? '' : 's'} to ${ctx.requireApp()}/${ctx.envName}?`, 'apply'))) {
    ctx.out.line('cancelled');
    return;
  }

  const api = ctx.api();
  const deployment = await api.createDeployment({
    kind: 'apply',
    manifest: checked.manifest,
    migrations: checked.migrations,
    base_version: ctx.baseVersion,
    ...(opts.force ? { force: true } : {}),
  });

  const { signal, dispose } = abortOnSigint();
  let result;
  try {
    result = await followDeployment(api, deployment.number, {}, signal);
  } finally {
    dispose();
  }
  if (result.aborted) {
    ctx.out.line(`stopped following; apply #${deployment.number} continues (boxlite-app app deployment ${deployment.number} --follow)`);
    return;
  }

  const final = result.deployment;
  const added = applicable.filter((c) => c.kind === '+').map((c) => c.path);
  const summary = added.length > 0 ? `Provision ${added.join(', ')}` : `Apply ${applicable.map((c) => c.path).join(', ')}`;
  const status = result.status === 'live' ? 'done' : result.status;
  const specText = final.spec_version !== undefined ? ` · spec v${final.spec_version}` : '';
  ctx.out.line(`#${final.number}  ${pad(summary, 50)}${status}${specText}`);
  if (final.url && result.status === 'live') ctx.out.line(`url: ${final.url}`);
  ctx.out.data(final);

  if (result.status === 'failed') throw deployFailedError(final);
  if (final.spec_version !== undefined) await updateLink(ctx.cwd, { base_version: final.spec_version });
}

export function registerApply(program: Command, make: MakeCtx): void {
  program
    .command('apply')
    .description('provision the resources in boxlite.toml (database, volumes, auth, variables) without uploading code')
    .option('-y, --yes', 'do not ask for confirmation')
    .option('--force', 'apply even when the local base version is behind the environment')
    .action(async (opts: { force?: boolean }, cmd: Command) => apply(await make(cmd), opts));
}
