import { MicrocloudError } from '@microcloud/shared';
import type { Command } from 'commander';
import type { PlanResponse } from '../api.js';
import type { MakeCtx } from '../cli.js';
import type { Ctx } from '../context.js';
import { formatChange, pad } from '../output.js';
import { invalidManifestError, planRequest, requireCheck, uploadSummary, type CheckedProject } from './common.js';

export interface PlanOutcome {
  checked: CheckedProject;
  plan: PlanResponse;
}

export function staleError(plan: PlanResponse, baseVersion: number): MicrocloudError {
  return new MicrocloudError('stale_base', `boxlite.toml is based on spec v${baseVersion} but the environment is at v${plan.latest_version}`, 'run `boxlite-app app pull` to sync, then re-apply your changes; or pass --force', {
    base_version: baseVersion,
    latest_version: plan.latest_version,
  });
}

/** check → POST /plan → print the plan; throws on manifest errors (7) and stale base (9, unless forced). */
export async function runPlan(ctx: Ctx, force: boolean): Promise<PlanOutcome> {
  const checked = await requireCheck(ctx);
  const plan = await ctx.api().plan(planRequest(ctx, checked, force));
  const app = ctx.requireApp();

  ctx.out.data({ app, environment: ctx.envName, base_version: ctx.baseVersion, ...plan, upload: { files: checked.upload.files.length, bytes: checked.upload.bytes }, warnings: [...checked.result.warnings, ...(plan.warnings ?? [])] });
  ctx.out.line(`App ${app} · environment ${ctx.envName} · based on v${ctx.baseVersion} (latest v${plan.latest_version})${plan.stale ? ' · stale' : ''}`);
  for (const c of plan.changes ?? []) ctx.out.line(formatChange(c));
  if ((plan.changes ?? []).length === 0) ctx.out.line('  (no changes)');
  ctx.out.line(`  ${pad('files to upload', 18)}${uploadSummary(checked)}`);
  for (const w of plan.warnings ?? []) ctx.out.line(`  warning  ${w.rule}  ${w.message}`);
  if (plan.errors?.length) {
    const result = { ok: false, errors: plan.errors, warnings: plan.warnings ?? [] };
    if (!ctx.json) for (const e of plan.errors) ctx.out.line(`${e.file}${e.line !== undefined ? `:${e.line}` : ''}  ${e.rule}  ${e.message}`);
    throw invalidManifestError(result, !ctx.json);
  }
  if (plan.stale && !force) throw staleError(plan, ctx.baseVersion);
  return { checked, plan };
}

export function registerPlan(program: Command, make: MakeCtx): void {
  program
    .command('plan')
    .description('show what apply/deploy would change in this environment (exit 9 when boxlite.toml is stale)')
    .option('--force', 'plan even when the local base version is behind the environment')
    .action(async (opts: { force?: boolean }, cmd: Command) => {
      await runPlan(await make(cmd), opts.force === true);
    });
}
