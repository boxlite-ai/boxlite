import { MicrocloudError, nextMigrationName, parseManifest, readMigrations, MANIFEST_FILE } from '@microcloud/shared';
import type { Command } from 'commander';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { SqlResult } from '../api.js';
import type { MakeCtx } from '../cli.js';
import type { Ctx } from '../context.js';
import { formatAgo, formatBytes, formatValue, table } from '../output.js';
import { parseInteger } from './common.js';

function printResult(ctx: Ctx, result: SqlResult): void {
  ctx.out.data(result);
  const columns = result.columns ?? [];
  const rows = (result.rows ?? []).map((r) => (Array.isArray(r) ? r : columns.map((c) => (r as Record<string, unknown>)[c])).map((v) => formatValue(v)));
  if (columns.length > 0) for (const line of table([columns, columns.map((c) => '-'.repeat(c.length)), ...rows])) ctx.out.line(line);
  ctx.out.line(`${result.row_count ?? rows.length} rows · ${result.elapsed_ms ?? 0} ms`);
}

async function sql(ctx: Ctx, query: string, opts: { write?: boolean; explain?: boolean }): Promise<void> {
  printResult(ctx, await ctx.api().sql(query, { write: opts.write === true, explain: opts.explain === true }));
}

async function info(ctx: Ctx): Promise<void> {
  const db = await ctx.api().dbInfo();
  ctx.out.data(db);
  ctx.out.line(`database ${db.status}${db.branch ? ` · branch ${db.branch}` : ''}${db.size_bytes !== undefined ? ` · ${formatBytes(db.size_bytes)}` : ''}`);
  if (db.host) ctx.out.line(`  host      ${db.host}`);
  if (db.database) ctx.out.line(`  database  ${db.database}`);
  if (db.user) ctx.out.line(`  user      ${db.user}`);
}

async function schema(ctx: Ctx, tableName?: string): Promise<void> {
  const data = await ctx.api().dbSchema(tableName);
  ctx.out.data(data);
  ctx.out.raw(ctx.json ? '' : JSON.stringify(data, null, 2));
}

async function rows(ctx: Ctx, tableName: string, opts: { where?: string; limit?: string; offset?: string }): Promise<void> {
  const data = await ctx.api().dbRows(tableName, {
    where: opts.where,
    limit: opts.limit !== undefined ? parseInteger(opts.limit, '--limit') : undefined,
    offset: opts.offset !== undefined ? parseInteger(opts.offset, '--offset') : undefined,
  });
  if ('columns' in data) {
    printResult(ctx, data);
    return;
  }
  const list = (data.rows ?? []) as Record<string, unknown>[];
  const columns = list.length ? Object.keys(list[0]!) : [];
  printResult(ctx, { columns, rows: list.map((r) => columns.map((c) => r[c])), elapsed_ms: 0, row_count: list.length });
}

async function migrations(ctx: Ctx): Promise<void> {
  const list = await ctx.api().dbMigrations();
  ctx.out.data(list);
  if (list.length === 0) ctx.out.line('no migrations');
  for (const line of table(list.map((m) => [m.file, m.status, m.deployment !== undefined ? `#${m.deployment}` : '']))) ctx.out.line(line);
}

async function migrationNew(ctx: Ctx, name: string): Promise<void> {
  let source: string;
  try {
    source = await readFile(join(ctx.cwd, MANIFEST_FILE), 'utf8');
  } catch {
    throw new MicrocloudError('missing_manifest', 'boxlite.toml not found', 'run `boxlite-app init`');
  }
  const parsed = parseManifest(source, ctx.envName);
  const dir = parsed.manifest?.database?.migrations ?? 'migrations/';
  if (!parsed.manifest?.database) ctx.out.note(`note: boxlite.toml has no [database] section; add it so ${dir} runs on deploy`);
  const existing = parsed.manifest ? await readMigrations(ctx.cwd, { ...parsed.manifest, database: { migrations: dir } }) : { files: [] };
  const file = nextMigrationName(existing.files, name);
  await mkdir(join(ctx.cwd, dir), { recursive: true });
  await writeFile(join(ctx.cwd, dir, file), `-- ${name}\n`, { flag: 'wx' });
  ctx.out.line(`created ${dir}${file}`);
  ctx.out.data({ file: `${dir}${file}` });
}

async function snapshot(ctx: Ctx, opts: { message?: string }): Promise<void> {
  if (!opts.message) throw new MicrocloudError('usage', 'a message is required: app db snapshot -m "before import"');
  const snap = await ctx.api().createDbSnapshot(opts.message);
  ctx.out.data(snap);
  ctx.out.line(`snapshot ${snap.id} created`);
}

async function snapshots(ctx: Ctx): Promise<void> {
  const list = await ctx.api().dbSnapshots();
  ctx.out.data(list);
  if (list.length === 0) ctx.out.line('no snapshots');
  for (const line of table(list.map((s) => [s.id, formatAgo(s.created_at), s.message ?? '']))) ctx.out.line(line);
}

async function restore(ctx: Ctx, opts: { to?: string; snapshot?: string }): Promise<void> {
  if (!opts.to && !opts.snapshot) throw new MicrocloudError('usage', 'pass --to <iso8601> or --snapshot <id>');
  const target = opts.snapshot ? `snapshot ${opts.snapshot}` : `point in time ${opts.to}`;
  if (!(await ctx.confirm(`Restore the ${ctx.envName} database to ${target}? Current data will be replaced.`, 'restore the database'))) {
    ctx.out.line('cancelled');
    return;
  }
  const result = await ctx.api().dbRestore({ to: opts.to, snapshot: opts.snapshot });
  ctx.out.data(result ?? { restored: target });
  ctx.out.line(`restored to ${target}`);
}

export function registerDb(app: Command, make: MakeCtx): void {
  app
    .command('sql <query>')
    .description('run SQL against the environment database (read-only unless --write)')
    .option('--write', 'allow statements that modify data or schema')
    .option('--explain', 'return the query plan instead of rows')
    .action(async (query: string, opts: { write?: boolean; explain?: boolean }, cmd: Command) => sql(await make(cmd), query, opts));

  const db = app.command('db').description('database info, schema, rows, migrations, snapshots');
  db.command('info').description('connection and size summary').action(async (_o: unknown, cmd: Command) => info(await make(cmd)));
  db
    .command('schema [table]')
    .description('tables and columns')
    .action(async (tableName: string | undefined, _o: unknown, cmd: Command) => schema(await make(cmd), tableName));
  db
    .command('rows <table>')
    .description('print rows of a table')
    .option('--where <expr>', 'SQL filter expression')
    .option('--limit <n>', 'max rows', '50')
    .option('--offset <n>', 'skip rows')
    .action(async (tableName: string, opts: { where?: string; limit?: string; offset?: string }, cmd: Command) => rows(await make(cmd), tableName, opts));
  db.command('migrations').description('applied/pending/changed migration files').action(async (_o: unknown, cmd: Command) => migrations(await make(cmd)));
  db
    .command('migration')
    .description('migration files')
    .command('new <name>')
    .description('create the next NNNN_<name>.sql file locally')
    .action(async (name: string, _o: unknown, cmd: Command) => migrationNew(await make(cmd), name));
  db
    .command('snapshot')
    .description('take a database snapshot')
    .requiredOption('-m, --message <text>', 'what this snapshot is for')
    .action(async (opts: { message?: string }, cmd: Command) => snapshot(await make(cmd), opts));
  db.command('snapshots').description('list snapshots').action(async (_o: unknown, cmd: Command) => snapshots(await make(cmd)));
  db
    .command('restore')
    .description('restore the database to a point in time or a snapshot')
    .option('--to <iso8601>', 'point in time')
    .option('--snapshot <id>', 'snapshot id')
    .option('-y, --yes', 'do not ask for confirmation')
    .action(async (opts: { to?: string; snapshot?: string }, cmd: Command) => restore(await make(cmd), opts));
}
