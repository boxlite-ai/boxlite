import { exposedService } from '@microcloud/shared';
import type { Command } from 'commander';
import type { Deployment, LogEvent, StepEvent } from '../api.js';
import type { MakeCtx } from '../cli.js';
import { updateLink, type Ctx } from '../context.js';
import { abortOnSigint, deployFailedError, followDeployment, type FollowResult } from '../follow.js';
import { formatBytes, stepLabel, stepLine } from '../output.js';
import { uploadSnapshot } from '../upload.js';
import { requireCheck, type CheckedProject } from './common.js';

const LOG_TAIL_KEEP = 20;

/** Human detail for a step when the event carries none; derived from the local manifest. */
export function stepDetail(ev: StepEvent, checked: CheckedProject | null, uploaded?: number): string {
  if (ev.detail) return ev.detail;
  if (!checked) return '';
  const m = checked.manifest;
  switch (ev.name) {
    case 'upload':
      return uploaded !== undefined ? `${uploaded} files` : `${checked.upload.files.length} files`;
    case 'build':
      return m.runtime.build.length > 0 ? m.runtime.build.join(' && ') : '(no build step)';
    case 'migrate':
      return m.database ? `${checked.migrations.length} file${checked.migrations.length === 1 ? '' : 's'} in ${m.database.migrations}` : '';
    case 'start': {
      const svc = exposedService(m);
      return svc ? (svc.command ? `${svc.name}  ${svc.command}` : `${svc.name}  static ${svc.static}`) : '';
    }
    default:
      return '';
  }
}

export interface FollowPrinter {
  onStep: (ev: StepEvent) => void;
  onLog: (ev: LogEvent) => void;
  logTail: string[];
}

/** Prints `#N  Building    npm ci && npm run build   41s` as steps finish; keeps a log tail for failures. */
export function followPrinter(ctx: Ctx, number: number, checked: CheckedProject | null, opts: { logs?: boolean; uploaded?: number } = {}): FollowPrinter {
  const logTail: string[] = [];
  return {
    logTail,
    onStep(ev) {
      if (ev.status === 'running') ctx.out.progress(`#${number}  ${stepLabel(ev.name)} …`);
      else ctx.out.line(stepLine(number, ev.name, stepDetail(ev, checked, opts.uploaded), ev.ms, ev.status));
    },
    onLog(ev) {
      logTail.push(ev.source ? `[${ev.source}] ${ev.line}` : ev.line);
      if (logTail.length > LOG_TAIL_KEEP) logTail.shift();
      if (opts.logs) ctx.out.line(`    ${ev.source ? `${ev.source} | ` : ''}${ev.line}`);
    },
  };
}

/** Final line for a finished deployment plus link.json update; throws (exit 8) when it failed. */
export async function finishDeployment(ctx: Ctx, result: FollowResult, number: number, printer: FollowPrinter): Promise<Deployment | null> {
  if (result.aborted) {
    ctx.out.line(`stopped following; deployment #${number} continues (boxlite-app app deployment ${number} --follow)`);
    return null;
  }
  const final = result.deployment;
  if (result.status === 'live') {
    ctx.out.line(stepLine(number, 'live', `${final.url ?? ''}${final.spec_version !== undefined ? ` · spec v${final.spec_version}` : ''}`.trim()));
    if (final.spec_version !== undefined) await updateLink(ctx.cwd, { base_version: final.spec_version });
  } else if (result.status !== 'failed') {
    ctx.out.line(`#${number}  ${result.status}`);
  }
  ctx.out.data(final);
  if (result.status === 'failed') {
    if (!final.error?.log_tail?.length && !final.log_tail?.length) final.log_tail = printer.logTail;
    throw deployFailedError(final);
  }
  return final;
}

async function deploy(ctx: Ctx, opts: { message?: string; detach?: boolean; force?: boolean }): Promise<void> {
  const checked = await requireCheck(ctx);
  const api = ctx.api();

  const upload = await uploadSnapshot(api, ctx.cwd, checked.upload, (p) => {
    if (p.done === 0) ctx.out.line(p.total === 0 ? 'Nothing new to upload' : `Uploading ${p.total} files changed (${formatBytes(p.bytes)})`);
    else ctx.out.progress(`  ${p.done}/${p.total} uploaded`);
  });
  ctx.out.clearProgress();

  const deployment = await api.createDeployment({
    kind: 'deploy',
    snapshot_id: upload.snapshot_id,
    manifest: checked.manifest,
    migrations: checked.migrations,
    base_version: ctx.baseVersion,
    ...(opts.message ? { message: opts.message } : {}),
    ...(opts.force ? { force: true } : {}),
  });
  const number = deployment.number;

  if (opts.detach) {
    ctx.out.line(`Deployment #${number} started (detached); follow with \`boxlite-app app deployment ${number} --follow\``);
    ctx.out.data(deployment);
    return;
  }
  ctx.out.line(`Deployment #${number} started${opts.message ? ` · ${opts.message}` : ''}`);

  const printer = followPrinter(ctx, number, checked, { uploaded: upload.uploaded });
  const { signal, dispose } = abortOnSigint();
  let result: FollowResult;
  try {
    result = await followDeployment(api, number, printer, signal);
  } finally {
    dispose();
  }
  await finishDeployment(ctx, result, number, printer);
}

export function registerDeploy(program: Command, make: MakeCtx): void {
  program
    .command('deploy')
    .description('upload the project, build and start it on the environment, and follow the deployment')
    .option('-m, --message <text>', 'deployment message')
    .option('--detach', 'return as soon as the deployment is queued')
    .option('--force', 'deploy even when the local base version is behind the environment')
    .option('-y, --yes', 'accepted for symmetry with apply; deploy never prompts')
    .action(async (opts: { message?: string; detach?: boolean; force?: boolean }, cmd: Command) => deploy(await make(cmd), opts));
}
