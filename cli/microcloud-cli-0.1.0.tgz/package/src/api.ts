import { MicrocloudError, type CheckError, type CheckWarning, type Manifest, type MigrationFile, type UploadFile } from '@microcloud/shared';
import { randomUUID } from 'node:crypto';
import { fetch, type Dispatcher, type Response } from 'undici';
import type { PlanChange } from './output.js';
import { parseJsonData, parseSse, type SseEvent } from './sse.js';

export interface EnvSummary {
  name: string;
  status?: string;
  url?: string;
  spec_version?: number;
  latest_deployment?: { number: number; status: string; spec_version?: number } | null;
  [extra: string]: unknown;
}

export interface AppInfo {
  name: string;
  envs?: EnvSummary[];
  [extra: string]: unknown;
}

export interface PlanRequest {
  manifest: Manifest;
  base_version: number;
  migrations: MigrationFile[];
  upload?: { files: number; bytes: number; warnings: string[] };
}

export interface PlanResponse {
  latest_version: number;
  stale: boolean;
  changes: PlanChange[];
  errors: CheckError[];
  warnings: CheckWarning[];
}

export interface DeploymentStep {
  name: string;
  status: string;
  ms?: number;
  detail?: string;
}

export interface DeploymentError {
  step?: string;
  message?: string;
  log_tail?: string[];
}

export interface Deployment {
  number: number;
  kind: string;
  status: string;
  message?: string | null;
  by?: string;
  created_at?: string;
  finished_at?: string | null;
  spec_version?: number;
  base_version?: number;
  snapshot_id?: string | null;
  steps?: DeploymentStep[];
  changes?: PlanChange[];
  error?: DeploymentError | null;
  url?: string;
  log_tail?: string[];
  [extra: string]: unknown;
}

export type DeploymentRequest =
  | { kind: 'deploy' | 'apply'; snapshot_id?: string; manifest: Manifest; migrations: MigrationFile[]; base_version: number; message?: string; force?: boolean }
  | { kind: 'rollback'; to: number; with_database?: boolean };

export interface StepEvent {
  name: string;
  status: 'running' | 'done' | 'failed' | string;
  ms?: number;
  detail?: string;
}

export interface LogEvent {
  ts?: string;
  source?: string;
  level?: string;
  line: string;
}

export interface DoneEvent {
  status: string;
  deployment: Deployment;
}

export interface ServiceStatus {
  name: string;
  state: string;
  restarts?: number;
  last_exit_code?: number | null;
  health?: string;
  pid?: number | null;
}

export interface DbInfo {
  status: string;
  host?: string;
  database?: string;
  user?: string;
  branch?: string;
  size_bytes?: number;
}

export interface SqlResult {
  columns: string[];
  rows: unknown[][];
  elapsed_ms: number;
  row_count: number;
}

export interface MigrationStatus {
  file: string;
  status: 'applied' | 'pending' | 'changed' | string;
  deployment?: number;
}

export interface DbSnapshot {
  id: string;
  message?: string;
  created_at?: string;
  [extra: string]: unknown;
}

export interface LogsQuery {
  source?: string;
  since?: string;
  limit?: number;
}

export interface ApiOptions {
  baseUrl: string;
  key: string;
  app?: string;
  env?: string;
  dispatcher?: Dispatcher;
}

interface RequestOptions {
  body?: unknown;
  raw?: Buffer;
  query?: Record<string, string | number | boolean | undefined>;
  headers?: Record<string, string>;
  accept?: string;
  signal?: AbortSignal;
}

const STATUS_CODES: Record<number, string> = { 401: 'unauthenticated', 403: 'forbidden', 404: 'not_found', 502: 'unavailable', 503: 'unavailable', 504: 'unavailable' };

/** Typed client for the `/v1` control-plane API (contracts §1 and §4) with the error → exit-code mapping. */
export class Api {
  readonly baseUrl: string;
  private readonly key: string;
  private readonly appName: string | undefined;
  private readonly envName: string | undefined;
  private readonly dispatcher: Dispatcher | undefined;

  constructor(opts: ApiOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/+$/, '');
    this.key = opts.key;
    this.appName = opts.app;
    this.envName = opts.env;
    this.dispatcher = opts.dispatcher;
  }

  /** Same credentials, scoped to another App or environment. */
  scoped(app: string, env?: string): Api {
    return new Api({ baseUrl: this.baseUrl, key: this.key, app, env: env ?? this.envName, dispatcher: this.dispatcher });
  }

  private get app(): string {
    if (!this.appName) throw new MicrocloudError('not_linked', 'this directory is not linked to an App', 'run `boxlite-app init` here, or set BOXLITE_APP');
    return encodeURIComponent(this.appName);
  }

  private get envPath(): string {
    if (!this.envName) throw new MicrocloudError('not_linked', 'no environment selected', 'pass --env <name>');
    return `/v1/apps/${this.app}/envs/${encodeURIComponent(this.envName)}`;
  }

  async request(method: string, path: string, opts: RequestOptions = {}): Promise<Response> {
    const url = new URL(this.baseUrl + path);
    for (const [k, v] of Object.entries(opts.query ?? {})) if (v !== undefined && v !== '') url.searchParams.set(k, String(v));
    const headers: Record<string, string> = { authorization: `Bearer ${this.key}`, accept: opts.accept ?? 'application/json', ...opts.headers };
    let body: string | Buffer | undefined;
    if (opts.raw !== undefined) {
      body = opts.raw;
      headers['content-type'] = 'application/octet-stream';
    } else if (opts.body !== undefined) {
      body = JSON.stringify(opts.body);
      headers['content-type'] = 'application/json';
    }
    let res: Response;
    try {
      res = await fetch(url, { method, headers, body, signal: opts.signal, ...(this.dispatcher ? { dispatcher: this.dispatcher } : {}) });
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e;
      const cause = (e as Error & { cause?: Error }).cause;
      throw new MicrocloudError('unavailable', `cannot reach ${url.origin}: ${cause?.message ?? (e as Error).message}`, 'check BOXLITE_API_URL and that the control plane is running');
    }
    if (res.ok) return res;
    throw await this.toError(res, method, path);
  }

  private async toError(res: Response, method: string, path: string): Promise<MicrocloudError> {
    const text = await res.text().catch(() => '');
    let parsed: { error?: { code?: string; message?: string; next?: string; [k: string]: unknown } } | undefined;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = undefined;
    }
    const err = parsed?.error;
    if (err && typeof err.code === 'string') {
      const { code, message, next, ...details } = err;
      return new MicrocloudError(code, typeof message === 'string' ? message : `${method} ${path} failed (${res.status})`, typeof next === 'string' ? next : undefined, details);
    }
    const code = STATUS_CODES[res.status] ?? `http_${res.status}`;
    const summary = text.trim().slice(0, 200) || res.statusText;
    return new MicrocloudError(code, `${method} ${path} failed: ${res.status} ${summary}`.trim(), res.status >= 500 ? 'retry in a moment' : undefined);
  }

  private async json<T>(method: string, path: string, opts: RequestOptions = {}): Promise<T> {
    const res = await this.request(method, path, opts);
    if (res.status === 204) return undefined as T;
    return (await res.json()) as T;
  }

  private async *sse(path: string, opts: RequestOptions = {}): AsyncGenerator<SseEvent> {
    const res = await this.request('GET', path, { ...opts, accept: 'text/event-stream' });
    if (!res.body) return;
    yield* parseSse(res.body as unknown as AsyncIterable<Uint8Array>);
  }

  // Apps

  getApp(name = this.appName ?? 'me'): Promise<AppInfo> {
    return this.json('GET', `/v1/apps/${encodeURIComponent(name)}`);
  }

  async getContext(format: 'markdown' | 'json'): Promise<string> {
    const res = await this.request('GET', `/v1/apps/${this.app}/context`, { query: { format }, accept: format === 'json' ? 'application/json' : 'text/markdown' });
    return res.text();
  }

  listEnvs(): Promise<EnvSummary[]> {
    return this.json('GET', `/v1/apps/${this.app}/envs`);
  }

  createEnv(body: { name: string; from?: string; with_data?: boolean }): Promise<EnvSummary> {
    return this.json('POST', `/v1/apps/${this.app}/envs`, { body });
  }

  deleteEnv(name: string): Promise<void> {
    return this.json('DELETE', `/v1/apps/${this.app}/envs/${encodeURIComponent(name)}`);
  }

  getEnv(): Promise<EnvSummary> {
    return this.json('GET', this.envPath);
  }

  // Spec, plan, uploads, deployments

  getSpec(version?: number): Promise<Record<string, unknown>> {
    return this.json('GET', `${this.envPath}/spec`, { query: { version } });
  }

  plan(body: PlanRequest): Promise<PlanResponse> {
    return this.json('POST', `${this.envPath}/plan`, { body });
  }

  createUpload(manifest: UploadFile[]): Promise<{ upload_id: string; missing: string[] }> {
    return this.json('POST', `/v1/apps/${this.app}/uploads`, { body: { manifest } });
  }

  async putFile(uploadId: string, sha256: string, bytes: Buffer): Promise<void> {
    await this.request('PUT', `/v1/apps/${this.app}/uploads/${encodeURIComponent(uploadId)}/files/${sha256}`, { raw: bytes });
  }

  completeUpload(uploadId: string): Promise<{ snapshot_id: string; files: number; bytes: number }> {
    return this.json('POST', `/v1/apps/${this.app}/uploads/${encodeURIComponent(uploadId)}/complete`, { body: {} });
  }

  createDeployment(body: DeploymentRequest): Promise<Deployment> {
    return this.json('POST', `${this.envPath}/deployments`, { body, headers: { 'idempotency-key': randomUUID() } });
  }

  listDeployments(limit?: number): Promise<Deployment[]> {
    return this.json('GET', `${this.envPath}/deployments`, { query: { limit } });
  }

  getDeployment(n: number): Promise<Deployment> {
    return this.json('GET', `${this.envPath}/deployments/${n}`);
  }

  cancelDeployment(n: number): Promise<Deployment> {
    return this.json('POST', `${this.envPath}/deployments/${n}/cancel`, { body: {} });
  }

  deploymentEvents(n: number, opts: { signal?: AbortSignal; lastEventId?: string } = {}): AsyncGenerator<SseEvent> {
    const headers = opts.lastEventId !== undefined ? { 'last-event-id': opts.lastEventId } : undefined;
    return this.sse(`${this.envPath}/deployments/${n}/events`, { signal: opts.signal, headers });
  }

  async deploymentSource(n: number): Promise<AsyncIterable<Uint8Array>> {
    const res = await this.request('GET', `${this.envPath}/deployments/${n}/source`, { accept: 'application/gzip' });
    if (!res.body) throw new MicrocloudError('unavailable', 'empty source archive', 'retry in a moment');
    return res.body as unknown as AsyncIterable<Uint8Array>;
  }

  // Runtime

  listServices(): Promise<ServiceStatus[]> {
    return this.json('GET', `${this.envPath}/services`);
  }

  restartService(name: string): Promise<void> {
    return this.json('POST', `${this.envPath}/services/${encodeURIComponent(name)}/restart`, { body: {} });
  }

  runSchedule(name: string): Promise<unknown> {
    return this.json('POST', `${this.envPath}/schedules/${encodeURIComponent(name)}/run`, { body: {} });
  }

  async getLogs(q: LogsQuery): Promise<LogEvent[]> {
    const data = await this.json<LogEvent[] | { lines?: LogEvent[]; logs?: LogEvent[] }>('GET', `${this.envPath}/logs`, { query: { ...q } });
    if (Array.isArray(data)) return data;
    return data.lines ?? data.logs ?? [];
  }

  followLogs(q: LogsQuery, signal?: AbortSignal): AsyncGenerator<SseEvent> {
    return this.sse(`${this.envPath}/logs`, { query: { ...q, follow: 1 }, signal });
  }

  getAccess(): Promise<{ access: string }> {
    return this.json('GET', `${this.envPath}/access`);
  }

  setAccess(access: string): Promise<{ access: string }> {
    return this.json('PUT', `${this.envPath}/access`, { body: { access } });
  }

  // Database

  dbInfo(): Promise<DbInfo> {
    return this.json('GET', `${this.envPath}/db`);
  }

  dbSchema(table?: string): Promise<unknown> {
    return this.json('GET', `${this.envPath}/db/schema${table ? `/${encodeURIComponent(table)}` : ''}`);
  }

  dbRows(table: string, q: { where?: string; limit?: number; offset?: number }): Promise<SqlResult | { rows: unknown[] }> {
    return this.json('GET', `${this.envPath}/db/rows/${encodeURIComponent(table)}`, { query: q });
  }

  sql(query: string, opts: { write?: boolean; explain?: boolean }): Promise<SqlResult> {
    return this.json('POST', `${this.envPath}/db/sql`, { body: { query, ...opts } });
  }

  dbMigrations(): Promise<MigrationStatus[]> {
    return this.json('GET', `${this.envPath}/db/migrations`);
  }

  dbSnapshots(): Promise<DbSnapshot[]> {
    return this.json('GET', `${this.envPath}/db/snapshots`);
  }

  createDbSnapshot(message: string): Promise<DbSnapshot> {
    return this.json('POST', `${this.envPath}/db/snapshots`, { body: { message } });
  }

  dbRestore(body: { to?: string; snapshot?: string }): Promise<unknown> {
    return this.json('POST', `${this.envPath}/db/restore`, { body });
  }

  devEnv(): Promise<{ env: Record<string, string> }> {
    return this.json('GET', `${this.envPath}/dev-env`);
  }
}

export function eventData<T>(ev: SseEvent): T | undefined {
  return parseJsonData<T>(ev);
}
