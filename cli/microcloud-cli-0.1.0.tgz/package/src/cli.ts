import { MicrocloudError, type CheckResult } from '@microcloud/shared';
import { Command, CommanderError } from 'commander';
import { registerApp } from './commands/app.js';
import { registerApply } from './commands/apply.js';
import { registerBuild } from './commands/build.js';
import { registerCheck } from './commands/check.js';
import { registerDeploy } from './commands/deploy.js';
import { registerInit } from './commands/init.js';
import { registerPlan } from './commands/plan.js';
import { createCtx, type Ctx, type GlobalOpts, type RunOptions } from './context.js';
import { checkLines } from './output.js';

export type MakeCtx = (cmd: Command) => Promise<Ctx>;

export const VERSION = '0.1.0';

export function buildProgram(run: RunOptions): Command {
  const program = new Command('boxlite-app')
    .description('BoxLite Micro-cloud: deploy and operate an App from its project directory')
    .version(VERSION)
    .option('--json', 'machine-readable output; errors go to stderr as {"error":{code,message,next}}')
    .option('--env <name>', 'environment (default: .boxlite/link.json env, else main)')
    .exitOverride()
    .configureOutput({
      writeOut: (s) => run.io.stdout.write(s),
      writeErr: (s) => run.io.stderr.write(s),
    });

  const make: MakeCtx = (cmd) => createCtx(run, cmd.optsWithGlobals() as GlobalOpts);
  registerInit(program, make);
  registerCheck(program, make);
  registerPlan(program, make);
  registerApply(program, make);
  registerDeploy(program, make);
  registerBuild(program, make);
  registerApp(program, make);
  return program;
}

/** Runs the CLI with the given argv (without node/script) and returns the exit code. */
export async function run(argv: string[], opts: RunOptions): Promise<number> {
  const json = argv.includes('--json');
  const program = buildProgram(opts);
  try {
    await program.parseAsync(argv, { from: 'user' });
    return 0;
  } catch (e) {
    if (e instanceof CommanderError) {
      if (e.code === 'commander.helpDisplayed' || e.code === 'commander.version' || e.code === 'commander.help') return 0;
      if (json) opts.io.stderr.write(`${JSON.stringify({ error: { code: 'usage', message: e.message.trim(), next: 'run `boxlite-app --help`' } })}\n`);
      return e.exitCode || 1;
    }
    const err = e instanceof MicrocloudError ? e : new MicrocloudError('internal', (e as Error)?.message ?? String(e));
    printError(opts, json, err);
    if (!(e instanceof MicrocloudError) && opts.env.BOXLITE_DEBUG) opts.io.stderr.write(`${(e as Error).stack ?? ''}\n`);
    return err.exit;
  }
}

function printError(opts: RunOptions, json: boolean, err: MicrocloudError): void {
  const { stderr } = opts.io;
  if (json) {
    stderr.write(`${JSON.stringify(err.toBody())}\n`);
    return;
  }
  stderr.write(`error: ${err.message}\n`);
  const details = err.details;
  if (Array.isArray(details.errors) && err.code === 'invalid_manifest' && details.printed !== true) {
    const result = { ok: false, errors: details.errors, warnings: [] } as CheckResult;
    for (const line of checkLines(result)) stderr.write(`  ${line}\n`);
  }
  if (typeof details.step === 'string') stderr.write(`  step: ${details.step}\n`);
  if (Array.isArray(details.log_tail) && details.log_tail.length > 0) {
    stderr.write('  last log lines:\n');
    for (const line of details.log_tail) stderr.write(`    ${String(line)}\n`);
  }
  if (err.next) stderr.write(`  next: ${err.next}\n`);
}
