import { MicrocloudError } from '@microcloud/shared';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { createInterface } from 'node:readline';
import type { Readable, Writable } from 'node:stream';
import type { Dispatcher } from 'undici';
import { Api } from './api.js';
import { Output } from './output.js';

export interface Io {
  stdout: Writable;
  stderr: Writable;
  stdin: Readable;
  isTTY: boolean;
}

export interface RunOptions {
  cwd: string;
  env: NodeJS.ProcessEnv;
  io: Io;
  /** undici dispatcher; tests inject a MockAgent. */
  dispatcher?: Dispatcher;
}

export interface Link {
  app: string;
  env: string;
  /** Spec version the local boxlite.toml was last synced with; 0 when the env has no spec yet. */
  base_version: number;
  api_url: string;
}

export const LINK_FILE = join('.boxlite', 'link.json');

export async function readLink(cwd: string): Promise<Link | null> {
  let text: string;
  try {
    text = await readFile(join(cwd, LINK_FILE), 'utf8');
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null;
    throw e;
  }
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new MicrocloudError('invalid_link', `${LINK_FILE} is not valid JSON`, 'delete it and run `boxlite-app init`');
  }
  const link = data as Partial<Link>;
  if (typeof link.app !== 'string' || typeof link.env !== 'string') {
    throw new MicrocloudError('invalid_link', `${LINK_FILE} must contain app and env`, 'delete it and run `boxlite-app init`');
  }
  return { app: link.app, env: link.env, base_version: typeof link.base_version === 'number' ? link.base_version : 0, api_url: typeof link.api_url === 'string' ? link.api_url : '' };
}

export async function writeLink(cwd: string, link: Link): Promise<void> {
  const path = join(cwd, LINK_FILE);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(link, null, 2)}\n`);
}

/** Merges `patch` into the existing link.json; a no-op when the project is not linked. */
export async function updateLink(cwd: string, patch: Partial<Link>): Promise<Link | null> {
  const current = await readLink(cwd);
  if (!current) return null;
  const next = { ...current, ...patch };
  await writeLink(cwd, next);
  return next;
}

export interface GlobalOpts {
  json?: boolean;
  env?: string;
  yes?: boolean;
}

export class Ctx {
  readonly cwd: string;
  readonly env: NodeJS.ProcessEnv;
  readonly io: Io;
  readonly json: boolean;
  readonly yes: boolean;
  readonly envName: string;
  readonly link: Link | null;
  readonly out: Output;
  readonly dispatcher: Dispatcher | undefined;
  private apiInstance: Api | undefined;

  constructor(run: RunOptions, opts: GlobalOpts, link: Link | null) {
    this.cwd = run.cwd;
    this.env = run.env;
    this.io = run.io;
    this.json = opts.json === true;
    this.yes = opts.yes === true;
    this.link = link;
    this.envName = opts.env ?? link?.env ?? 'main';
    this.out = new Output(run.io, this.json);
    this.dispatcher = run.dispatcher;
  }

  get apiKey(): string | undefined {
    return this.env.BOXLITE_API_KEY || undefined;
  }

  get apiUrl(): string | undefined {
    return this.env.BOXLITE_API_URL || this.link?.api_url || undefined;
  }

  get app(): string | undefined {
    return this.link?.app ?? this.env.BOXLITE_APP ?? undefined;
  }

  /** Spec version the local manifest is based on (0 = none yet). */
  get baseVersion(): number {
    return this.link?.base_version ?? 0;
  }

  requireApp(): string {
    const app = this.app;
    if (!app) throw new MicrocloudError('not_linked', 'this directory is not linked to an App', 'run `boxlite-app init` here, or set BOXLITE_APP');
    return app;
  }

  api(): Api {
    if (this.apiInstance) return this.apiInstance;
    const key = this.apiKey;
    if (!key) throw new MicrocloudError('unauthenticated', 'BOXLITE_API_KEY is not set', 'export BOXLITE_API_KEY=bxl_app_… (the App key from the console)');
    const url = this.apiUrl;
    if (!url) throw new MicrocloudError('missing_api_url', 'BOXLITE_API_URL is not set and .boxlite/link.json has no api_url', 'export BOXLITE_API_URL=https://<control-plane>');
    this.apiInstance = new Api({ baseUrl: url, key, app: this.app, env: this.envName, dispatcher: this.dispatcher });
    return this.apiInstance;
  }

  /** Resolves true when the action may proceed. `--yes` and `--json` skip the prompt; without a TTY the command refuses instead of hanging. */
  async confirm(question: string, action: string): Promise<boolean> {
    if (this.yes || this.json) return true;
    if (!this.io.isTTY) throw new MicrocloudError('confirmation_required', `refusing to ${action} without --yes`, `rerun with --yes`);
    const rl = createInterface({ input: this.io.stdin, output: this.io.stdout });
    try {
      const answer = await new Promise<string>((resolve) => rl.question(`${question} [y/N] `, resolve));
      return /^y(es)?$/i.test(answer.trim());
    } finally {
      rl.close();
    }
  }
}

export async function createCtx(run: RunOptions, opts: GlobalOpts): Promise<Ctx> {
  return new Ctx(run, opts, await readLink(run.cwd));
}
